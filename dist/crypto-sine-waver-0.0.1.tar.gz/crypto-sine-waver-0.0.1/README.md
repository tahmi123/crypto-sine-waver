# Crypto-sim

Crypto_sine_waver/crypto-sine_-aver is a Python library for dealing with cryptography(secure encryption and decryption).

## Installation

Use the package manager [pip]pyto install crypto-sine-waver.

```
pip install crypto-sine-waver
```

## Usage

```python
from crypto_sine_waver import sine

sine(price)

[CODE]

[LICENSE]


